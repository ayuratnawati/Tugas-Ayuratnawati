<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datafutsal extends CI_Controller {

  public function __construct() {
		parent::__construct();
		$this->load->model('Ekskul_model');
	    $this->load->model('Futsal_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Futsal',
			'anggota' => $this->Ekskul_model->getAnggotaFutsal()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Futsal_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data Futsal/index', $data);
	}
}