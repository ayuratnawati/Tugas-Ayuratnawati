<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dataops extends CI_Controller {

  public function __construct() {
		parent::__construct();
		$this->load->model('Ekskul_model');
	    $this->load->model('Ops_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Ops',
			'anggota' => $this->Ekskul_model->getAnggotaOps()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Ops_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data Ops/index', $data);
	}
}