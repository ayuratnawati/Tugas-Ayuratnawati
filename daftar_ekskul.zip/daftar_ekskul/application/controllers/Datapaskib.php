<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datapaskib extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('Ekskul_model');
	     $this->load->model('Paskibra_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Paskibra',
			'anggota' => $this->Ekskul_model->getAnggotaPaskibra()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Paskibra_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data Paskibra/index', $data);
	}
}

