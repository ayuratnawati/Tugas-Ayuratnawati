<?php
defined('BASEPATH')OR exit('No direct script access allowed');

class Datainori extends CI_Controller {

  public function __construct() {
		parent::__construct();
		$this->load->model('Ekskul_model');
	    $this->load->model('Inori_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Inori',
			'anggota' => $this->Ekskul_model->getAnggotaInori()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Inori_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data Inori/index', $data);
	}
}