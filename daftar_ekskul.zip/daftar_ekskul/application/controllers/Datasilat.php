<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datasilat extends CI_Controller {

 public function __construct() {
		parent::__construct();
		$this->load->model('Ekskul_model');
	    $this->load->model('Silat_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Silat',
			'anggota' => $this->Ekskul_model->getAnggotaSilat()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Silat_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data Silat/index', $data);
	}
}