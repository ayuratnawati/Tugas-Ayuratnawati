<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datapramuka extends CI_Controller {

  public function __construct() {
		parent::__construct();
		$this->load->model('Ekskul_model');
	    $this->load->model('Pramuka_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Pramuka',
			'anggota' => $this->Ekskul_model->getAnggotaPramuka()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Pramuka_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data Pramuka/index', $data);
	}
}