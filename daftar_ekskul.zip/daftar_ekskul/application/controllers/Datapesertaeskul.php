<?php


class Datapesertaeskul extends CI_Controller {

    public function __construct() {
        parent:: __construct();
        $this->load->library('session');
        $this->load->model('Ekskul_model');
        $this->load->library('form_validation');
    }

    public function index() {
        $data['judul'] = 'Daftar Ekskul';
        $this->load->view('pendaftaran/paskibra/Tambah', $data);
    }


    public function detailvoli($id_pendaftaran){

        // $data['judul'] = 'Detail Data Ekskul';
        $data['anggota'] = $this->Ekskul_model->getPendaftaranById($id_pendaftaran);
        $this->load->view('Data peserta/data_voli/detail', $data);

    }

    public function detailanderpati($id_pendaftaran){

        // $data['judul'] = 'Detail Data Ekskul';
        $data['anggota'] = $this->Ekskul_model->getPendaftaranById($id_pendaftaran);
        $this->load->view('Data peserta/data anderpati/detail', $data);

    }

    public function detailbasket($id_pendaftaran){

        // $data['judul'] = 'Detail Data Ekskul';
        $data['anggota'] = $this->Ekskul_model->getPendaftaranById($id_pendaftaran);
        $this->load->view('Data peserta/data basket/detail', $data);

    }

    public function detailboxer($id_pendaftaran){

        // $data['judul'] = 'Detail Data Ekskul';
        $data['anggota'] = $this->Ekskul_model->getPendaftaranById($id_pendaftaran);
        $this->load->view('Data peserta/data boxer/detail', $data);

    }






    public function tambah() {
		$data['judul'] = 'form Tambah Data eskul';

        $this->form_validation->set_rules('nama', 'Nama','required');
        $this->form_validation->set_rules('agama', 'Agama','required');
        $this->form_validation->set_rules('no-tlp', 'No-tlp','required');
        $this->form_validation->set_rules('jurusan', 'Jurusan','required');
        $this->form_validation->set_rules('Nama_ekskul', 'Nama_ekskul','required');

        if( $this->form_validation->run() == TRUE) {
            if( $this->input->post('Nama_ekskul') == 'Paskibra' ){
                $this->Ekskul_model->tambah();
                $this->session->set_flashdata('flash','Ditambahkan');
                redirect('datapaskib');

            } elseif ( $this->input->post('Nama_ekskul') == 'Pmr' ) {
                $this->Ekskul_model->tambah();
                $this->session->set_flashdata('flash','Ditambahkan');
                redirect('datapmr');

            } elseif ($this->input->post('Nama_ekskul') == 'Inori') {//nangkap inputan
                     $this->Ekskul_model->tambah();
                     $this->session->set_flashdata('flash','Ditambahkan');
                     redirect('datainori');

            } elseif ($this->input->post('Nama_ekskul') == 'Anderpati') {
                     $this->Ekskul_model->tambah();
                     $this->session->set_flashdata('flash','Ditambahkan');
                     redirect('dataanderpati');

            } elseif ($this->input->post('Nama_ekskul') == 'Ops'){
                    $this->Ekskul_model->tambah();
                    $this->session->set_flashdata('flash','Ditambahkan');
                    redirect('dataops');

            } elseif ($this->input->post('Nama_ekskul') == 'English club'){
                    $this->Ekskul_model->tambah();
                    $this->session->set_flashdata('flash','Ditambahkan');
                    redirect('dataec');       
                
            } elseif ($this->input->post('Nama_ekskul') == 'Basket'){
                    $this->Ekskul_model->tambah();
                    $this->session->set_flashdata('flash','Ditambahkan');
                    redirect('databasket');

            } elseif ($this->input->post('Nama_ekskul') == 'Paduanmusik'){
                    $this->Ekskul_model->tambah();
                    $this->session->set_flashdata('flash','Ditambahkan');
                    redirect('datapaduanmusik');

            } elseif ($this->input->post('Nama_ekskul') == 'Boxer'){
                    $this->Ekskul_model->tambah();
                    $this->session->set_flashdata('flash','Ditambahkan');
                    redirect('databoxer');

            } elseif ($this->input->post('Nama_ekskul') == 'Futsal'){
                    $this->Ekskul_model->tambah();
                    $this->session->set_flashdata('flash','Ditambahkan');
                    redirect('datafutsal');

            } elseif ($this->input->post('Nama_ekskul') == 'Silat'){
                    $this->Ekskul_model->tambah();
                    $this->session->set_flashdata('flash','Ditambahkan');
                    redirect('datasilat');

            } elseif ($this->input->post('Nama_ekskul') == 'Pramuka'){
                    $this->Ekskul_model->tambah();
                    $this->session->set_flashdata('flash','Ditambahkan');
                    redirect('datapramuka');  

            } elseif ($this->input->post('Nama_ekskul') == 'Voli'){
                    $this->Ekskul_model->tambah();
                    $this->session->set_flashdata('flash','Ditambahkan');
                    redirect('datavoli'); 

            } elseif ($this->input->post('Nama_ekskul') == 'Rohis'){
                    $this->Ekskul_model->tambah();
                    $this->session->set_flashdata('flash','Ditambahkan');
                    redirect('datarohis');

            } elseif ($this->input->post('Nama_ekskul') == 'Senitari'){
                    $this->Ekskul_model->tambah();
                    $this->session->set_flashdata('flash','Ditambahkan');
                    redirect('datasenitari'); 

            } else {
                    $this->load->view('pendaftaran/paskibra/Tambah', $data);
            }
        }
    }
}