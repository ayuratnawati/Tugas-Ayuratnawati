<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datasenitari extends CI_Controller {

 public function __construct() {
		parent::__construct();
		$this->load->model('Ekskul_model');
	    $this->load->model('Senitari_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Senitari',
			'anggota' => $this->Ekskul_model->getAnggotaSenitari()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Senitari_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data Senitari/index', $data);
	}
}