<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Databoxer extends CI_Controller {

 public function __construct() {
		parent::__construct();
		$this->load->model('Ekskul_model');
	    $this->load->model('Boxer_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Boxer',
			'anggota' => $this->Ekskul_model->getAnggotaBoxer()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Boxer_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data Boxer/index', $data);
	}
}
