<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Databasket extends CI_Controller {

 public function __construct() {
		parent::__construct();
		$this->load->model('Ekskul_model');
	   $this->load->model('Basket_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Basket',
			'anggota' => $this->Ekskul_model->getAnggotaBasket()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Basket_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data Basket/index', $data);
	}
}
