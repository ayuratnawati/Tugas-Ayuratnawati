<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datarohis extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('Ekskul_model');
	    $this->load->model('Rohis_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Rohis',
			'anggota' => $this->Ekskul_model->getAnggotaRohis()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Rohis_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data Rohis/index', $data);
	}
}
