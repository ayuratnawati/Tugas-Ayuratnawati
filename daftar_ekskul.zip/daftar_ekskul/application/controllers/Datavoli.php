<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datavoli extends CI_Controller {

  public function __construct() {
		 parent::__construct();
		 $this->load->model('Ekskul_model');
	     $this->load->model('Voli_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Voli',
			'anggota' => $this->Ekskul_model->getAnggotaVoli()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Voli_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data_Voli/index', $data);
	}
}