<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datapaduanmusik extends CI_Controller {

  public function __construct() {
		parent::__construct();
		$this->load->model('Ekskul_model');
	    $this->load->model('Paduanmusik_model');
	}

	public function index()
	{
		$data = [
			'judul' => 'Data Paduanmusik',
			'anggota' => $this->Ekskul_model->getAnggotaPaduanmusik()
		];


		if ($this->input->post('keyword')) {

        	$data['anggota'] = $this->Paduanmusik_model->cariDataEkskul();

        }

		$this->load->view('data peserta/data Paduanmusik/index', $data);
	}
}
