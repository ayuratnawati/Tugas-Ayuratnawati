<DOCTYPE! html>
<html>
<head>
  <title>halaman index</title>
  <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/home.css">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
</head>
<body>
      <div class="header1">
      <div id="navigasi">
    <ul>
        <li><a href="#">SIMANIS</a></li>
        <li style="float:right"><a href="html1.html">komunitas</a></li>
        <li style="float:right"><a href="new 2.html">Raport</a></li>
        <li style="float:right"><a href="new 2.html">Hubin System</a></li>
        <li style="float:right"><a href="new 2.html">Absensi</a></li>
        <li style="float:right"><a href="new 2.html">Eskul</a></li>
      </ul>
   </div>  
  </div>

<div class="image-top">
  <div class="lapisanimage">
    <h1 class="txt-it1">PENDAFTARAN EKSTRAKURIKULER</h1><br>
    <h3 class="txt-it2">SMKN 1 KOTA BEKASI</h3>
  </div>
</div>

<div class="ultramilk">
  <div class="box1">
    <center>
      <a href="<?= base_url(); ?>daftar"><img src="<?= base_url(); ?>assets/img/daftar10.png" style="width: 210px; height: 210px; border-radius: 100%; cursor:pointer;">
    </center></a>
      <p>Pendaftaran Ekskul</p>
  </div>
  
  <div class="box1">
    <center>
      <a href="<?= base_url(); ?>Data_peserta"><img src="assets/img/7896.png" style="width: 210px; height: 210px; border-radius: 100%;">
    </center></a>
      <p>Data Peserta</p>
  </div>
  <div class="box1">
    <center>
      <a href="<?= base_url(); ?>Contact_person"><img src="assets/img/profile.png" style="width: 205px; height: 205px; border-radius: 100%;">
    </center></a>
      <p>Contact Person</p>
  </div>
</div>
   
<div class="footer-top">
  <div class="konten1">
    <div class="line"></div>
          <h3>PENDAFTARAN</h3>
          <h3>EKSKUL</h3>
          <P>Aplikasi yang mempermudah peserta ekskul untuk mendaftar
            dirinya ke salah satu ekstrakurikuler yang diminati.

          </P>
  </div>
  <div class="konten2">
    <h5>USEFUL LINKS</h5>
          <div class="line2">
            <div class="l-line"></div>
          </div>
          <li><a href="#">Home</a></li><hr class="line2">
          <li><a href="#">Busines</a></li><hr class="line2">
          <li><a href="#">Product</a></li><hr class="line2">
          <li><a href="#">About Us</a></li><hr class="line2">
          <li><a href="#">Contact Us</a></li><hr class="line2">
  </div>
  <div class="konten3">
    <h5>FOLLOW US</h5>
          <div class="line2">
            <div class="l-line"></div>
            <li><a href="#"><i class="fab fa-twitter t" style="margin-left: -60px; padding: 10px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook f" style="margin-left: -5px; padding: 10px 12px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram i" style="margin-left: 10px; padding: 10px 12px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-youtube y" style="margin-left: 10px; padding: 10px 10px; border-radius: 100%;"></i></a></li>
          </div>
  </div>
  <div class="konten4">
    <h5>OUR NEWSLETTER</h5>
          <div class="line2">
            <div class="l-line"></div>
          </div>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum totam pariatur dolor atque minus, laborum impedit eligendi vitae recusandae, distinctio neque itaque, fugit magni incidunt harum aliquid tenetur deleniti! Vero?</p> 
  </div>
</div>
<div class="footer-bottom">
        <p>Hak Cipta © Ayuratnawati corporation</p>
</div>
</body>
</html>




 

  