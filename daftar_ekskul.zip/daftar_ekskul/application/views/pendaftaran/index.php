<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/bootstrap.css">
    
    <!-- Native CSS -->
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/aln.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/kontak/kontak.css">

    <!-- Icon -->
    <link rel="shortcut icon" href="<?= base_url(); ?>assets/img/logo.jpg">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

    <!-- Hover -->
    <link href="css/hover.css" rel="stylesheet" media="all">

    <title>Simanis | Ekstrakurikuler</title>
</head>
<body>
    <!-- Ini Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark biru fixed-top">
        <a class="navbar-brand" href="#" style="font-size: 19px !important;">
            <img src="<?= base_url();?>assets/img/icon-pendaftaran-png-7.png" width="100" class="d-inline-block" alt="">
            PENDAFTARAN EKSKUL
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse putih" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto topnav">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url();?>Home">Home</a>
                </li>
  
                <li class="nav-item">
                    <a class="nav-link active" href="#">Ekskul <span class="sr-only">(current)</span></a>
                </li>
                
            </ul>
        </div>
    </nav>

    
     <div class="jumbotron text-center marginol">
      <div class="artikel1 kolom1"><img src="<?=base_url();?>assets/img/daftar10.png"></div>
      <div class="h2">SELAMAT DATANG DI SITUS PENDAFTARAN</div>
      <div class="h1">EKSTRAKURIKULER</div>
    </div>
    <!-- akhir header/jumbotron -->

    <!-- awal section -->
    <section class="latar warnadrop bg-primary">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center marginatas">
            <h1><b>MOTIVASI</b></h1>
          </div>
        </div>
        <div class="row marginatas">
          <div class="col-sm-3 text-center marginbawah">
            <a href=""><img src="<?= base_url();?>assets/img/34.png" class="img-thumbnail rounded-circle lebar"></a>
            <h4><b></b></h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua.</p>
          </div>
          <div class="col-sm-3 text-center marginbawah">
            <a href=""><img src="<?= base_url();?>assets/img/34.png" class="img-thumbnail rounded-circle lebar"></a>
            <h4><b></b></h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua.</p>
          </div>
          <div class="col-sm-3 text-center marginbawah">
            <a href=""><img src="<?= base_url();?>assets/img/34.png" class="img-thumbnail rounded-circle lebar"></a>
            <h4><b></b></h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua.</p>
          </div>
          <div class="col-sm-3 text-center marginbawah">
            <a href=""><img src="<?= base_url();?>assets/img/34.png" class="img-thumbnail rounded-circle lebar"></a>
            <h4><b></b></h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua.</p>
          </div>
        </div>
      </div>
    </section>
    
    <div class="judul">
      <h1>PILIH EKSTRAKURIKULER KESUKAANMU</h1>
    </div>
<div class="product">

    <div class="baris_kedua">
      <div class="box">
        <div class="imgBx">
          <a href="<?= base_url(); ?>desain_ops"><img src="<?= base_url();?>assets/img/45.jpg" style="width: 350px; height: 480px">
        </div>
        
          </ul>
        <div class="details2">
          <h2>OPS<br/><span></span></h2>
        </div>
      </div>
    </div>

     <div class="baris_kedua2">
      <div class="box">
        <div class="imgBx">
          <a href="<?= base_url(); ?>desain_pmr"><img src="<?= base_url();?>assets/img/99.png" style="width: 350px; height: 480px">
        </div>
          
          </ul>
        <div class="details2">
          <h2>PMR<br/><span></span></h2>
        </div>
      </div>
    </div>

    <div class="baris_kedua3">
      <div class="box">
        <div class="imgBx">
          <a href="<?= base_url(); ?>desain_inori"><img src="<?= base_url();?>assets/img/images.jpg" style="width: 350px; height: 500px">
        </div>
         
        <div class="details2">
          <h2>INOSAI<br/><span></span></h2>
        </div>
      </div>
    </div>

    <div class="baris_kedua4">
      <div class="box">
        <div class="imgBx">
         <a href="<?= base_url(); ?>desain_pramuka"> <img src="<?= base_url();?>assets/img/900.jpg" style="width: 350px; height: 475px">
        </div>
          
          </ul>
        <div class="details2">
          <h2>PRAMUKA<br/><span></span></h2>
        </div>
      </div>
    </div>

    <div class="baris_kedua5">
      <div class="box">
        <div class="imgBx">
          <a href="<?= base_url(); ?>desain_rohis"><img src="<?= base_url();?>assets/img/78.png" style="width: 350px; height: 500px">
        </div>
          
          </ul>
        <div class="details2">
          <h2>ROHIS<br/><span></span></h2>
        </div>
      </div>
    </div>

    <div class="baris_kedua6">
      <div class="box">
        <div class="imgBx">
         <a href="<?= base_url(); ?>desain_paskibra"><img src="<?= base_url();?>assets/img/12.jpg" style="width: 350px; height: 480px">
        </div>
          
          </ul>
        <div class="details2">
          <h2>PASKIBRAKA<br/><span></span></h2>
        </div>
      </div>
    </div>
    <div class="baris_kedua7">
      <div class="box">
        <div class="imgBx">
          <a href="<?= base_url(); ?>desain_anderpati"><img src="<?= base_url();?>assets/img/download.png" style="width: 350px; height: 480px">
        </div>
          
          </ul>
        <div class="details2">
          <h2>ANDERPATI<br/><span></span></h2>
        </div>
      </div>
    </div>
    <div class="baris_kedua8">
      <div class="box">
        <div class="imgBx">
          <a href="<?= base_url(); ?>desain_basket"><img src="<?= base_url();?>assets/img/89.jpeg" style="width: 350px; height: 480px">
        </div>
          
          </ul>
        <div class="details2">
          <h2>BASKET<br/><span></span></h2>
        </div>
      </div>
    </div>
    <div class="baris_kedua9">
      <div class="box">
        <div class="imgBx">
          <a href="<?= base_url(); ?>desain_boxer"><img src="<?= base_url();?>assets/img/logo2.jpg" style="width: 350px; height: 480px">
        </div>
          
          </ul>
        <div class="details2">
          <h2>BOXER<br/><span></span></h2>
        </div>
      </div>
    </div>
    <div class="baris_kedua10">
      <div class="box">
        <div class="imgBx">
           <a href="<?= base_url(); ?>desain_silat"><img src="<?= base_url();?>assets/img/logo3.jpg" style="width: 350px; height: 480px">
        </div>
          
          </ul>
        <div class="details2">
          <h2>PENCAK SILAT<br/><span></span></h2>
        </div>
      </div>
    </div>
     <div class="baris_kedua11">
      <div class="box">
        <div class="imgBx">
         <a href="<?= base_url(); ?>desain_musik"> <img src="<?= base_url();?>assets/img/logo8.jpg" style="width: 350px; height: 480px">
        </div>
          
          </ul>
        <div class="details2">
          <h2>PADUAN SUARA<br/><span></span></h2>
        </div>
      </div>
    </div>

    <div class="baris_kedua12">
      <div class="box">
        <div class="imgBx">
          <a href="<?= base_url(); ?>desain_ec"> <img src="<?= base_url();?>assets/img/9000.jpg" style="width: 350px; height: 480px">
        </div>
        
          </ul>
        <div class="details2">
          <h2>English club<br/><span></span></h2>
        </div>
      </div>
    </div>
    <div class="baris_kedua13">
      <div class="box">
        <div class="imgBx">
          <a href="<?= base_url(); ?>desain_voli"> <img src="<?= base_url();?>assets/img/68688.jpg" style="width: 350px; height: 480px">
        </div>
        
          </ul>
        <div class="details2">
          <h2>Voli<br/><span></span></h2>
        </div>
      </div>
    </div>
    <div class="baris_kedua14">
      <div class="box">
        <div class="imgBx">
          <a href="<?= base_url(); ?>desain_senitari"><img src="<?= base_url();?>assets/img/09.jpg" style="width: 350px; height: 480px">
        </div>
        
          </ul>
        <div class="details2">
          <h2>SENI TARI<br/><span></span></h2>
        </div>
      </div>
    </div>
    <div class="baris_kedua15">
      <div class="box">
        <div class="imgBx">
         <a href="<?= base_url(); ?>desain_futsal"> <img src="<?= base_url();?>assets/img/index333.png" style="width: 350px; height: 480px">
        </div>
        
          </ul>
        <div class="details2">
          <h2>FUTSAL<br/><span></span></h2>
        </div>
      </div>
    </div>
    
    


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>


</a></div>

<div class="footer-top">
  <div class="konten1">
    <div class="line"></div>
          <h3>PENDAFTARAN</h3>
          <h3>EKSKUL</h3>
          <P>Aplikasi yang mempermudah peserta ekskul untuk mendaftar
            dirinya ke salah satu ekstrakurikuler yang diminati.
          </P>
  </div>
  <div class="konten2">
    <h5>USEFUL LINKS</h5>
          <div class="line2">
            <div class="l-line"></div>
          </div>
          <li><a href="#">Home</a></li><hr class="line2">
          <li><a href="#">Busines</a></li><hr class="line2">
          <li><a href="#">Product</a></li><hr class="line2">
          <li><a href="#">About Us</a></li><hr class="line2">
          <li><a href="#">Contact Us</a></li><hr class="line2">
  </div>
  <div class="konten3">
    <h5>FOLLOW US</h5>
          <div class="line2">
            <div class="l-line"></div>
            <li><a href="#"><i class="fab fa-twitter t" style="margin-left: -60px; padding: 10px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook f" style="margin-left: -5px; padding: 10px 12px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram i" style="margin-left: 10px; padding: 10px 12px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-youtube y" style="margin-left: 10px; padding: 10px 10px; border-radius: 100%;"></i></a></li>
          </div>
  </div>
  <div class="konten4">
    <h5>OUR NEWSLETTER</h5>
          <div class="line2">
            <div class="l-line"></div>
          </div>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum totam pariatur dolor atque minus, laborum impedit eligendi vitae recusandae, distinctio neque itaque, fugit magni incidunt harum aliquid tenetur deleniti! Vero?</p> 
  </div>
</div>
<div class="footer-bottom">
        <p>Hak Cipta © Ayu ratnawati corporation</p>
</div>
</body>
</html>






  </body>
</html>