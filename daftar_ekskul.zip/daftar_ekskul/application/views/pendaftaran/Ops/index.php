<DOCTYPE! html>
<html>
<head>
  <title>Halaman desain OPS</title>
  <link rel="stylesheet" type="text/css" href="assets/css/halaman1.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>

	  <img src ="<?= base_url();?>assets/img/45.jpg">
     
    <center><div class="box1">
    <div class="header1">
    <div id="navigasi">
<ul>

      
      
      <li style="float:right"><a href="<?= base_url();?>daftar">Kembali</a></li>
      <li style="float:right"><a href="">Eskul</a></li>
</ul>
   </div>
        </div>
           


       <div class="text1"><p>Apa itu OPS?  
</div></p>
       <center><div class="text2"><p>Organisasi Perpustakaan Sekolah (OPS)</p>

       OPS adalah organisasi di sekolah yang berpusat di<p> perpustakaan,bergerak di bidang perpustakaan.</P></center>


    <div class="k"><p><li>Apa aja kegiatan di Ops?<br><p style="font-size: 25px;">1.Menjaga dan merawat perpus.<br>2.Merawat buku2.<br>3.Selalu merapihkan buku2.<br>3.Menjaga apabila ada yang ingin meminjam buku.<br></p></p></div></li>

    <div class="f"><p><li> Jadwal kegiatan ekskul OPS?<br><p style="font-size: 30px">Hari : senin-juma'at<br>pukul : setiap pulang sekolah.<br>pakaian : seragam.</p></li></p></div>


    <div class="w"><b>Ayooo!!!! Jadikan salah satu anggota ekskul OPS </b></div><br>

    <a href ="<?= base_url(); ?>datapesertaeskul"><button type="button" class="btn btn-primary" style="width: 25%; height: 50px">Daftar</button></a>
   




    





 

<br><br></center>







</div>

  </div>

      
