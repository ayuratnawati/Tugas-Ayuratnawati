<div class="container">

	<div class="row mt-3">
		<div class="col-md-6">

      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css" integrity="sha384-PDle/QlgIONtM1aqA2Qemk5gPOE7wFq8+Em+G/hmo5Iq0CCmYZLv3fVRDJ4MMwEA" crossorigin="anonymous">


			<div class="card">
            <div class="card-header">
               PENDAFTARAN EKSKUL
  </div>

        <div class="card-body">
        <?php if( validation_errors() ): ?>
        <div class="alert alert-danger" role="alert">
   	    <?= validation_errors(); ?>
</div>
         <?php endif; ?>
  
  	   <form action="<?= site_url('datapesertaeskul/tambah'); ?>" method="post">
			                   	<div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" name="nama" class="form-control" id="nama" >

                  </div>
                          
                          <div class="form-group">
                           <label for="agama">Agama</label>
                           <input type="text" name="agama" class="form-control" id="agama" >
                  </div>

                          <div class="form-group">
                            <label for="gender">gender</label>
                            <input type="text" name="gender" class="form-control" id="gender" >
                  </div>

                          <div class="form-group">
                            <label for="No-tlp">No-tlp</label>
                            <input type="number" name="no-tlp" class="form-control" id="No-tlp" >
                  </div>




    <div class="form-group">
      <label for="jurusan">jurusan</label>
      <select class="form-control" id="jurusan" name="jurusan">
        <option></option>
        <option value ="rpl">rpl</option>
        <option value ="Multi media">mm</option>
        <option value ="akuntansi">akuntansi</option>
        <option value ="tkj">tkj</option>
        <option value ="Busana Butik">Busana Butik</option>
        <option value ="Tpl">Tpl</option>
        <option value ="Tp">Tp</option>
        <option value ="Tkr">Tkr</option>
      </select>
   </div>



      <div class="form-group">
      <label for="jurusan">Nama Ekskul</label>
      <select class="form-control" id="Nama_Ekskul" name="Nama_ekskul">
      <option></option>
      <option value ="Paskibra">Paskibra</option>
      <option value ="Pmr">Pmr</option>
      <option value ="Inori">Inori</option>
      <option value ="Basket">Basket</option>
      <option value ="Voli">Voli</option>
      <option value ="Anderpati">Anderpati</option>
      <option value ="Senitari">Seni Tari</option>
      <option value ="English club">English Club</option>
      <option value ="Pramuka">Pramuka</option>
      <option value ="Rohis">Rohis</option>
      <option value ="Ops">OPS</option>
      <option value ="Silat">Silat</option>
      <option value ="Futsal">Futsal</option>
      <option value ="Paduanmusik">Paduan suara</option>
      <option value ="Boxer">Boxer</option>
      
      </select>
  </div>

           <button type="submit" name="tambah" class=" btn btn-primary">Simpan</button>
         </select>
        </div>
      </div>
    </form>
  </div>
</div>