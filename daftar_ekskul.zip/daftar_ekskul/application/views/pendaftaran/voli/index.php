<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">



    <link rel="stylesheet" href="<?= base_url();?>assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/desainpmr.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
    <!-- Native CSS -->
    <link rel ="stylesheet" type="text/css" href="../assets/css/dataeskul.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/kontak/kontak.css">

    <!-- Icon -->
    <link rel="shortcut icon" href="assets/img/logo.jpg">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

    <!-- Hover -->
    <link href="css/hover.css" rel="stylesheet" media="all">

    <title>Simanis | Ekstrakurikuler</title>
</head>
<body>
    <!-- Ini Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark biru fixed-top">
        <a class="navbar-brand" href="#" style="font-size: 19px !important;">
            <img src="<?= base_url();?>assets/img/icon-pendaftaran-png-7.png" width="100" class="d-inline-block" alt="" style="margin-left: 200px">
            PENDAFTARAN EKSKUL
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse putih" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto topnav">
                <li class="nav-item">
                    <a class="nav-link" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Absensi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Raport</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Komunitas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="#">Ekskul <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Hubin</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="tempatbox">
    <div class="tempat" style="width:90%; height:380px; ">
    <div class="t"><b><li>Voli</b></li>
    <div class="r"><center><p>Bola voli adalah permainan olahraga yang dimainkan <p>oleh dua grup berlawanan. Masing-masing grup <p>memiliki enam orang pemain.</p></p></p></div></div></div></center></div>


        <div class="tempatbok">
        <div class="tempat1" style="width:90%; height:360px; margin-top:120px; ">
       <div class="h"><b><li>Apa aja kegiatan di voli?</div></b><br></li>
                   <center><p style="font-size: 25px">1. Belajar mendalami voli<br>
                    2. Cara memainkan voli dengan benar
                  </center></p></center></b></div></div></div>



              <div class="tempatbou">
                  <div class="tempat2" style="width:90%; height:280px; margin-top:100px; ">
                 <div class="h"><b><li>Jadwal ekskul</div></b></li>
                 <center><p style="font-size: 29px">Hari : Sabtu<br>
                            baju : bebas<br>
                            celana :training<br>
                            pukul : 09:00 wib. <br>
                        </p></center></b></div></div>

                       

                  <div class="tempatboi">
                  <div class="tempat3" style="width:90%; height:350px; margin-top:100px;">
                 <div class="h"><p style="margin-top: 50px;">Ayooo!!! Daftarkan diri anda sebagai anggota ekskul Voli</div></p>
                 <br>


                  <center><a href ="<?= base_url(); ?>daftareskul"><button type="button" class="btn btn-primary" style="width: 25%; height: 50px;">Daftar</button></a></center>
                    </div>
                   </div>
                  </div>
                </div>
               </b>
            </div>
           </div>
         </div>
       </body>
   </html>
                     
      

  


    



  