<!doctype html>
<html lang="en">
<head>
  
        <meta charset="utf-8">
        <title>desain daftar</title>
        <style>
             body{
              padding: 0;
              margin:0;
              font-family: tahoma;

              }

    .vid-container{

      position: relative;
      height: 100vh;
      overflow: hidden;

}

        img{
        position: absolute;
        left: 0;
        top:0;
        width: 100vw;
      }
       
       .inner-container{
        width:50%;
        height:460px;
        /*position: absolute;
        top:calc(46vh-200px);
        left: calc(70vw-200px);*/
        overflow: hidden;
        background-color: rgba(0,0,0,0.61);


       }


       .box{
        position: absolute;
        height: 100%;
        width: 50%;
        font-family: tahoma;
        color:white;
        background: rgba(0,0,0,0.50);
        padding: 0px;
       }



       .box h1{

        text-align: center;
        margin:30px 0;
        font-size: 30px;
        font-family: tahoma;



       }




       .box input{
         display: block;
         width: 60%;
         height: 25px;
         margin: 20px auto;
         padding: 15px;
         background: rgba(0,0,0,0.2);
         color:white;
         border : 2px solid white;
         border-radius: 50px;
         font-size: 12px;
         font-family: tahoma;

       }

       .box input:focus,
       .box input:active,
       .box button:focus,
       .box input:active{
        outline: none;
       }


        .box button{
          background: #0077ff; 
          border: 0px;
          color:white;
          padding: 10px;
          font-size: 20px;
          width: 65%;
          margin:20px auto;
          display: block;
          cursor: pointer;
          border-radius: 10px;
          font-family: tahoma;
        }

        .box button:hover{
          background-color: #005DFF;
        }


        @media(max-width: 870px) {
          .inner-container{
            width: 80%;
          }
          .box{
            width: 80%;
          }
        }


        @media(max-width: 537px) {
          .box input{
            width: 80%;
            padding: 8px;
          }
          .box button{
            width: 85%;
            padding: 8px;
          }
      }
        
        select{
         display: block;
         width: 64%;
         height: 55px;
         margin: 20px auto;
         padding: 15px;
         background: rgba(0,0,0,0.2);
         color:white;
         border : 2px solid white;
         border-radius: 50px;
         font-size: 12px;
         font-family: tahoma;

        }

        option{
           background: rgba(0,0,0,0.2);


        }

        </style>
    </head>
<body>

                 

            <img src="<?= base_url(); ?>assets/img/7777.jpg" style="width: 100%; height:100%">
            <center>
            <div class="inner-container">
              <div class="box">
                <h1>Pendaftaran Ekskul</h1>
                <input type="text" placeholder="Username">
               
                <input type="text" placeholder="Agama">
                <input type="number" placeholder="No-Tlp">
                <select type="text" placeholder="Jurusan">
            <option>RPL</option>
            <option>MULTIMEDIA</option>
            <option>TKJ</option>
            <option>TPL</option>
            <option>TP</option>
            <option>TKR</option>
            <option>BB</option>
            <option>AKUNTANSI</option>
            </select>
            <select type="text" placeholder="Nama Ekskul">
            <option>Paskibra</option>
            <option>Pmr</option>
            <option>Inori</option>
            <option>Pramuka</option>
            <option>Seni tari</option>
            <option>Rohis</option>
            <option>Basket</option>
            <option>Voli</option>
            <option>Anderpati</option>
            <option>Ec</option>
        </select>

                

                <button>Simpan</button>
               </div>
             </div>
           </center>
        </body>
     </html>
          
   