<!DOCTYPE html>
<html>
<head>
	     <title>desain prmuka</title>
	     <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/pramuka.css">
       <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>

       <img src="<?= base_url();?>assets/img/900.jpg" style="width: 100%; height:800px">



        <div class="box1">
	      <div class="header1">
        <div id="navigasi">
<ul>

      
      <li style="float:right"><a href="<?= base_url();?>daftar">Kembali</a></li>
      <li style="float:right"><a href="">Eskul</a>    </li>
      </ul>
   </div> 
</div>


	      <center>
        <div class="P"><p>PRAMUKA?</p>
	      </div>
        </center>
	      <br>
	      <center>
        <div class="yu"><p>Ekstrakurikuler Pramuka</p>

        <p>Pramuka adalah singkatan dari Praja Muda Karana dan merupakan organisasi atau gerakan kepanduan. <p>Pramuka adalah sebuah organisasi yang merupakan wadah proses <p>pendidikankepramukaan yang dilaksanakan di Indonesia.
             </center>
         </p>  
      </p>
  </p>
              


            <center><div class="f"><p>Apa saja kegiatan pramuka?</p>
            <p style="font-size: 22pt">1. Melatih kedisiplinan<br>
            2. Belajar kepanduan<br>
            3. Ada perkemahan juga loh.</p></center>

            
            <br><br>
             <div class="i">Jadwal kegiatan ekskul.<br>
             <p style="font-size: 24pt;">Hari : setiap sabtu<br>Pakaian : Seragam <br> Pukul : 09:00/sd 17:00 wib </p><br><br>


          <div class="i"> Ayooo!!! Daftar kan diri anda segera.<br></div>
          <a href ="<?= base_url(); ?>datapesertaeskul"><button type="button" class="btn btn-primary" style="width: 25%; height: 50px; margin-left: 70px;">Daftar</button></a>
             
           </div>
             


             </div></div></div>




            

               



                   </body>
                       </html>