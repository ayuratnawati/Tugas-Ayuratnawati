<!DOCTYPE html>
<html>
<head>
	       <title>desain boxer</title>
	       <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/boxer.css">
          <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
</head>
<body>


          <img src="<?= base_url(); ?>assets/img/logo2.jpg">
</div>
          <div class="box1">
	        <div class="header1">
          <div id="navigasi">
<ul>
            
			      <li style="float:right"><a href="<?= base_url();?>daftar">Kembali</a></li>
			      <li style="float:right"><a href="new 2.html">Eskul</a></li>
</ul>
   
	         <div class="e"><b>Tarung Drajat</b>
           <p>Ekstrakurikuler Tarung Drajat

           <p>Tarung Derajat adalah seni bela diri berasal <p>dari Indonesia yang diciptakan oleh Achmad Dradjat. Ia mengembangkan <p>teknik melalui pengalamannya bertarung di jalanan pada tahun 1960-an di Bandung.</p></p></p></p>

           


           <br><br>
           <div class="e"><b>Kegiatan ekskul boxer</b>
           <p>1.Melatih kekuatan<br>
           2. Mempelajari gerakan-gerakan</p></div>


           <br><br>
           <div class="e"><b>Jadwal kegiatan ekskul</b>
           <p>1.Melatih kekuatan<br>
           2. Mempelajari gerakan-gerakan</p></div>
           

           <br><br><br>
           <div class="text4"><b>Ayooo!!! Daftarkan Diri anda sebagai anggota Tarung derajat.<br></b></div>

          <a href ="<?= base_url(); ?>datapesertaeskul"><button type="button" class="btn btn-primary" style="width: 25%; height: 50px">Daftar</button></a>



</div>
</div>
</div>
</div>





























</body>
</html>