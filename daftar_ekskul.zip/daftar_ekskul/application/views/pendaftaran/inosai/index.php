<!DOCTYPE html>
<html>
<head>
	     <title>Halaman desain inosai</title>
       <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/inosai.css">
       <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>


         <img src ="<?= base_url();?>assets/img/5678.jpg" style="width: 100%; height:100%">
         <b>INORI</b>
  

        <div class="box1">
        <div class="header1">
        <div id="navigasi">
<ul>

      
      
      <li style="float:right"><a href="<?= base_url();?>daftar">Kembali</a></li>
      <li style="float:right"><a href="">Eskul</a></li>
             </ul>
                  </div>
                        </div>


       <div class="text1"><p>Apa itu inori?
</div>
       <center><div class="text2"><p>Ekstrakurikuler Japan Club (INORI)

       <p>Japanese Club adalah sebuah kegiatan ekskul yang berhubungan dengan sesuatu yang berbau Jepang.

       <p>INORI dengan arti 'doa' adalah singkatan dari Ichiban No Hikari yang memiliki arti 'Cahaya Nomor 1'.
       <p>INORI adalah Japan Club yang ada di SMK Negeri 1 Kota Bekasi. Seperti Japan Club pada umumnya, <p>ekskul ini memiliki beberapa divisi yang bertujuan untuk mengembangkan kemampuan anggota <p>ekskul di beberapa bidang.</center></p></p></p></p></p></p></p></p><br><br>


       <div class="t"><p>Apa aja kegiatan di inori?
        <br><p style="font-size:25px;">1. Belajar bahasa jepang.<br>2. Mempelajari jepang2<br>3.Belajar dance ala jepang.</p></p>


        <br><div class="t"><p>Kegiatan Inori?
        <br><p style="font-size:25px;">Hari : Setiap sabtu
                                      <br>Pukul :10:00/sd 05:00<br>
                                      Pakaian : Baju pramuka
                                    </p></p>



        <br><div class="t"><p>Ayoooo!!! Daftarkan diri anda sebagai anggota ekskul INORI</p>
          
       <a href ="<?= base_url(); ?>datapesertaeskul"><button type="button" class="btn btn-primary" style="width: 25%; height: 50px; margin-left: 90px;">Daftar</button></a>

                 </center>
                       </div>
                            </div>
                                </div>
                            </div>
                        </div>
                     </div>
                  </div>
            </body>
       </html>