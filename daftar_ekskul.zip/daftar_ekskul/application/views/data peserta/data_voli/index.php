<!DOCTYPE html>
<html>
<head>
	<title>data voli</title>
	<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/datapaskib.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css" integrity="sha384-PDle/QlgIONtM1aqA2Qemk5gPOE7wFq8+Em+G/hmo5Iq0CCmYZLv3fVRDJ4MMwEA" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>


    <div class="header1">
    <div id="navigasi">
<ul>	
	
            <li><div class="text8">Data voli</div>
			      <li style="float:right"><a href="<?= base_url();?>data_peserta">kembali</a>
			    
        </ul>
    </li>
 </div>

 <div class ="row mt-3">
  <div class="col-md-3">
    <form action="" method="post">
      <div class="input-group ">
             <input type="text" class="form-control" placeholder="cari data peserta.." name="keyword">
                 <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">cari</button>
               </div>
           </div>
       </form>
   </div>
</div>


        <div class="box1" style="width: 100%; margin-top: 50px;"><p>DATA VOLI</p>
	      <br><br>
	      <center><table id="customers" style="width: 90%">
<tr>
      <th>nama</th>
      <th>jurusan</th>
      <th>agama</th>
      <th>no_tlp</th>
      <th>gender</th>
      <th>nama_ekskul</th>
      <th>Action</th>
  </tr>
      <?php foreach($anggota as $agt) : ?>
      <tr>
        <td><?= $agt['nama']; ?></td>
        <td><?= $agt['jurusan']; ?></td>
        <td><?= $agt['agama']; ?></td>
        <td><?= $agt['no_tlp']; ?></td>
        <td><?= $agt['gender']; ?></td>
        <td><?= $agt['Nama_ekskul']; ?></td>
        <td><a href="<?= base_url(); ?>datapesertaeskul/detailvoli/<?= $agt['id_pendaftaran']; ?>"><button type="button" class="btn btn-primary">Detail</button></td>
      </tr>
    <?php endforeach; ?>
  <tr>
   
    
  </center>
</table>
</div>

    	
    	
    	

