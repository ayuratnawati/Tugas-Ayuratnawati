<!DOCTYPE html>
<html>
<head>
	<title>Data English Club</title>
	<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/datapaskib.css">
</head>
<body>


    <div class="header1">
    <div id="navigasi">
<ul>	
	
            <li><div class="text8">Data English Club</div>
			      <li style="float:right"><a href="<?= base_url();?>data_peserta">kembali</a>
			      <li style="float:right"><a href="new 2.html"></a>
            <li style="float:right"><a href="new 2.html"></a>
        </ul>
    </li>
 </div>


        <div class="box1"><p>DATA ENGLISH CLUB</p>
	      <br><br>
	      <center><table id="customers" style="width: 80%">
<tr>
    <th>Nama lengkap</th>
    <th>Nama panggilan</th>
    <th>Jurusan</th>
    <th>Aksi</th>
</tr>
<tr>
    <td>Ayu ratna</td>
    <td>inces</td>
    <td>Rpl</td>
   
  </tr>
  <tr>
    <td>Berglunds snabbköp</td>
    <td>Christina Berglund</td>
    <td>Sweden</td>
    
  </tr>
  <tr>
<td>Berglunds snabbköp</td>
    <td>Christina Berglund</td>
    <td>Sweden</td>
    
  </tr>
  <tr>

    
    

  </center>
</table>
</div>

    	
    	
    	

