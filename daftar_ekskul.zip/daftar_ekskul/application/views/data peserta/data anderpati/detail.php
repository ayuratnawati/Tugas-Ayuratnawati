<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css" integrity="sha384-PDle/QlgIONtM1aqA2Qemk5gPOE7wFq8+Em+G/hmo5Iq0CCmYZLv3fVRDJ4MMwEA" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">



<div class="container">
	<div class="row mt-3 ">
		<div class="col-md-9 bg-warning"></div>


        <div class="card col-md-5">
        <div class="card-header">
        Detail Data Anderpati
</div>

              <div class="card-body">
              <h5 class="card-title">Nama : <?= $anggota ['nama']; ?></h5>
              <h6 class="card-subtitle mb-2 text-muted">Jurusan : <?= $anggota['jurusan']; ?></h6>
                 <p class="card-text"> Agama : <?=$anggota['agama'];?></p>
                 <p class="card-text"> No-Tlp :  <?=$anggota['no_tlp'];?></p>
                  <p class="card-text"> Gender : <?=$anggota['gender'];?></p>
                   <p class="card-text"> Nama Ekskul : <?=$anggota['Nama_ekskul'];?></p>
                 <a href="<?= base_url(); ?>dataanderpati" class="btn btn-primary">kembali</a>
              </div>
          </div>
      </div>
  </div>
