<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/bootstrap.css">
    
    <!-- Native CSS -->
    <link rel ="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/dataeskul.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/kontak/kontak.css">

    <!-- Icon -->
    <link rel="shortcut icon" href="<?= base_url();?>assets/img/logo.jpg">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

    <!-- Hover -->
    <link href="css/hover.css" rel="stylesheet" media="all">

    <title>Simanis | Ekstrakurikuler</title>
</head>
<body>
    <!-- Ini Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark biru fixed-top">
        <a class="navbar-brand" href="#" style="font-size: 19px !important;">
            <img src="assets/img/icon-pendaftaran-png-7.png" width="100" class="d-inline-block" alt="">
            PENDAFTARAN EKSKUL
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse putih" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto topnav">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url();?>Home">Home</a>
                </li>
               
                <li class="nav-item">
                    <a class="nav-link active" href="#">Ekskul <span class="sr-only">(current)</span></a>
            </ul>
        </div>
    </nav>

      <div class="tempat-foto">
      <img src="<?= base_url();?>assets/img/data.jpg" style="width: 65%; height:auto;">  <br>
</div>
<center>
      <h1>Data peserta ekskul </h1>
</center>
<br>
<center>
    

        <div class="box1">
        <table id="customers" style="width : 100%;">
<tr>
         <th>No</th>
         <th>Nama Ekskul</th>
         <th>Nama Kegiatan</th>
</tr>
<tr>
          <td>1</td>
          <td><a href="<?= base_url();?>datapaskib">PASKIBRA </td>
          <td>PASUKAN PENGIBAR BENDERA</td>
    </tr>
    <tr>
          <td>2</td>
          <td><a href="<?= base_url();?>datapmr">PMR </td>
          <td>BERGERAK DI BIDANG KESEHATAN</td>
    </tr>
    <tr>
            <td>3</td>
            <td><a href="<?= base_url();?>datainori">INORI </td>
            <td>BELAJAR BAHASA JEPANG DAN LAIN-LAIN</td>
    </tr>
    <tr>
          <td>4</td>
          <td><a href="<?= base_url();?>datapaduanmusik">PADUAN SUARA</td>
          <td>BERGERAK DI BIDANG MUSIK </td>
    </tr>
    <tr>
          <td>5</td>
          <td><a href="<?= base_url();?>dataops">OPS </td>
          <td>MENGURUS PERPUSTAKAAN</td>
    </tr>
    <tr>
         <td>6</td>
         <td><a href="<?= base_url();?>datapramuka">PRAMUKA</td>
         <td>kEPANDUAN</td>
    </tr>
    <tr>
         <td>7</td>
         <td><a href="<?= base_url();?>dataanderpati">ANDERPATI
         <td>BERGERAK DI BIDANG SENI</td>
    </tr>
    <tr>

        <td>8</td>
        <td><a href="<?= base_url();?>dataec">ENGLISH CLUB</td>
        <td>BERGERAK DI BIDANG BAHASA</td>
    </tr>
    <tr>
        <td>9</td>
        <td><a href="<?= base_url();?>datarohis">ROHIS</td>
        <td>BERGERAK DI BIDANG KEROHANIAN</td>
    </tr>
    <tr>
        <td>10</td>
        <td><a href="<?= base_url();?>datavoli">VOLI</td>
        <td>BERGERAK DI BIDANG OLAHRAGA</td>
    </tr>
    <tr>
        <td>11</td>
        <td><a href="<?= base_url();?>databasket">BASKET</td>
        <td>BERGERAK DI BIDANG OLAHRAGA</td>
    </tr>
    <tr>
        <td>12</td>
        <td><a href="<?= base_url();?>datasenitari">SENI TARI</td>
        <td>BERGERAK DI BIDANG SENI</td>
    </tr>
    <tr>
        <td>13</td>
        <td><a href="<?= base_url();?>datasilat">PENCAK SILAT</td>
        <td>BERGERAK DI BIDANG BELA DIRI</td>
    </tr>
    <tr>
        <td>14</td>
        <td><a href="<?= base_url();?>databoxer">TARUNG DERAJAT</td>
        <td>BERGERAK DI BIDANG OLAHRAGA</td>
    </tr>
    <tr>
        <td>15</td>
        <td><a href="<?= base_url();?>datafutsal">FUTSAL</td>
        <td>BERGERAK DI BIDANG OLAHRAGA</td>
    </tr>
    </table>
    </div>
</center>

<br><br><br>

<footer>
    <div class="konten1">
        <div class="line"></div>
            <h3>PENDAFTARAN</h3>
            <h3>EKSKUL</h3>
            <P>Aplikasi yang mempermudah peserta ekskul untuk mendaftar
            dirinya ke salah satu ekstrakurikuler yang diminati.
            </P>
        </div>
        <div class="konten2">
            <h5>OUR TEAM</h5>
                <div class="line2">
                    <div class="l-line"></div>
                </div>
                <li><a href="#">Raport</a></li><hr class="line2">
                <li><a href="#">Absensi</a></li><hr class="line2">
                <li><a href="#">Ekskul</a></li><hr class="line2">
                <li><a href="#">Komunitas</a></li><hr class="line2">
                <li><a href="#">Hubin</a></li><hr class="line2">
        </div>
        <div class="konten3">
            <h5>FOLLOW US</h5>
                <div class="line2">
                    <div class="l-line"></div>
                    <li><a href="#"><i class="fab fa-twitter t" style="margin-left: -60px; padding: 10px; border-radius: 100%;"></i></a></li>
                    <li><a href="#"><i class="fab fa-facebook f" style="margin-left: -5px; padding: 10px 12px; border-radius: 100%;"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram i" style="margin-left: 10px; padding: 10px 12px; border-radius: 100%;"></i></a></li>
                    <li><a href="#"><i class="fab fa-youtube y" style="margin-left: 10px; padding: 10px 10px; border-radius: 100%;"></i></a></li>
                </div>
        </div>
        <div class="konten4">
            <h5>OUR NEWSLETTER</h5>
                <div class="line2">
                    <div class="l-line"></div>
                </div>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum totam pariatur dolor atque minus, laborum impedit eligendi vitae recusandae, distinctio neque itaque, fugit magni incidunt harum aliquid tenetur deleniti! Vero?</p> 
        </div>
    <div class="footer-bottom">
        <p>Copyright &copy; 2019 Ayu ratnawati Production</p>
    </div>
    </footer>
</div>
</body>
</html>
