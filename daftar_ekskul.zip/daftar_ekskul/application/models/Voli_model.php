 <?php

class Voli_model extends CI_model{
        public function getAllMahasiswa(){
        	return $this->db->get('pendaftaran')->result_array();
		}


public function cariDataEkskul()
	{

		$keyword = $this->input->post('keyword', true);//true kalo datanya di insert ke database
		$this->db->like('nama', $keyword);
		$this->db->or_like('agama',$keyword);
		$this->db->or_like('gender',$keyword);
		$this->db->or_like('jurusan',$keyword);
		$this->db->where('Nama_ekskul', 'Anderpati');
 
		return $this->db->get('pendaftaran')->result_array();

	}
}
