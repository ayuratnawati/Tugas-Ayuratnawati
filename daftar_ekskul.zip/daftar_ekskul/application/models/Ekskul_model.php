 <?php

class Ekskul_model extends CI_model{
        public function getAllMahasiswa(){
        	return $this->db->get('pendaftaran')->result_array();
		}

	public function getAnggotaPaskibra() {//mengambil seluruh record yg nama ekskkulnya paskibra
		$this->db->select('*');//mengambil data seluruh field
		$this->db->from('pendaftaran');//table yang di ambil
		$this->db->where('Nama_ekskul', 'Paskibra');//yg persyaratan value dari field
		$hasil = $this->db->get()->result_array();//mengambil data dalam bentuk array
		return $hasil;//mengembalikan data
	}

	public function getAnggotaPmr(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Pmr');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	public function getAnggotainori(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Inori');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	public function getAnggotaPramuka(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Pramuka');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	public function getAnggotaRohis(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Rohis');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	// public function getAnggotaEnglishclub{
	// 	$this->db->select('*');
	// 	$this->db->from('pendaftaran');
	// 	$this->db->where('Nama_ekskul', 'English club');
	// 	$hasil = $this->db->get()->result_array();
	// 	return $hasil;
	// }

	public function getAnggotaAnderpati(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Anderpati');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	public function getAnggotaSenitari(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Senitari');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	public function getAnggotaSilat(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Silat');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	public function getAnggotaVoli(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Voli');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	public function getAnggotafutsal(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Futsal');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	public function getAnggotaPaduanmusik(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Paduanmusik');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	public function getAnggotaboxer(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Boxer');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	public function getAnggotaOps(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Ops');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}

	public function getAnggotaBasket(){
		$this->db->select('*');
		$this->db->from('pendaftaran');
		$this->db->where('Nama_ekskul', 'Basket');
		$hasil = $this->db->get()->result_array();
		return $hasil;
	}



    public function tambah()
	{

		$data = [	
			"nama"        => $this->input->post('nama', true),
            "jurusan"     => $this->input->post('jurusan',true),
            "agama"       => $this->input->post('agama',true),
            "no_tlp"      => $this->input->post('no-tlp',true),
            "gender"      => $this->input->post('gender',true),
            "Nama_ekskul" => $this->input->post('Nama_ekskul',true)
		];

        $this->db->insert('pendaftaran', $data);

	}

	public function getPendaftaranById($id_pendaftaran){

		return $this->db->get_where('pendaftaran', ['id_pendaftaran' => $id_pendaftaran])->row_array();
	}
}
