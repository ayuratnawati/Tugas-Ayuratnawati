-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2019 at 07:36 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rpl1718_4_10_ayuratnawati`
--
CREATE DATABASE IF NOT EXISTS `rpl1718_4_10_ayuratnawati` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `rpl1718_4_10_ayuratnawati`;

-- --------------------------------------------------------

--
-- Table structure for table `detail_transaksi`
--

CREATE TABLE `detail_transaksi` (
  `id_dtl_transaksi` varchar(10) NOT NULL,
  `no_transaksi` int(11) NOT NULL,
  `no_kamar` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_transaksi`
--

INSERT INTO `detail_transaksi` (`id_dtl_transaksi`, `no_transaksi`, `no_kamar`) VALUES
('091', 21, '01'),
('092', 22, '02');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_kamar`
--

CREATE TABLE `jenis_kamar` (
  `id_jenis_kamar` varchar(10) NOT NULL,
  `tipe_kamar` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_kamar`
--

INSERT INTO `jenis_kamar` (`id_jenis_kamar`, `tipe_kamar`) VALUES
('021', 'deluxe'),
('022', 'deluxe');

-- --------------------------------------------------------

--
-- Table structure for table `kamar`
--

CREATE TABLE `kamar` (
  `no_kamar` varchar(10) NOT NULL,
  `id_jenis_kamar` varchar(10) NOT NULL,
  `lantai_kamar` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kamar`
--

INSERT INTO `kamar` (`no_kamar`, `id_jenis_kamar`, `lantai_kamar`) VALUES
('01', '021', 2),
('02', '022', 3);

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `id_karyawan` varchar(10) NOT NULL,
  `nama_karyawan` varchar(50) NOT NULL,
  `jenis_kelamin` enum('pria','wanita') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `jenis_kelamin`) VALUES
('01', 'wati', 'wanita'),
('02', 'indah', 'wanita'),
('03', 'bayu', 'pria'),
('04', 'yayan', 'pria');

-- --------------------------------------------------------

--
-- Table structure for table `t_pengunjung`
--

CREATE TABLE `t_pengunjung` (
  `id_pengunjung` varchar(10) NOT NULL,
  `nama_pengunjung` varchar(30) NOT NULL,
  `alamat` varchar(20) NOT NULL,
  `jenis_kelamin` enum('pria','wanita') NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `no_ktp` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_pengunjung`
--

INSERT INTO `t_pengunjung` (`id_pengunjung`, `nama_pengunjung`, `alamat`, `jenis_kelamin`, `no_telp`, `no_ktp`) VALUES
('001', 'rahma dani', 'kp2', 'wanita', '4657864785648756', 2147483647),
('002', 'muhammad wahyu', 'duren sawit jakarta ', 'pria', '4665784785648756', 2147483647),
('003', 'gilang an', 'duren sawit jakarta ', 'pria', '4665784785696', 2147483647),
('004', 'bayu', 'jakarta', 'pria', '9576895768957689', 2147483647),
('006', 'dani', 'jakarta', 'pria', '56845698476859', 2147483647),
('007', 'yayan', 'bandung', 'wanita', '56895987568957', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `t_transaksi`
--

CREATE TABLE `t_transaksi` (
  `no_transaksi` int(11) NOT NULL,
  `id_pengunjung` varchar(20) NOT NULL,
  `id_karyawan` varchar(20) NOT NULL,
  `jml_kamar` int(11) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `tgl_keluar` date NOT NULL,
  `lama_nginap` int(11) NOT NULL,
  `total_harga` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_transaksi`
--

INSERT INTO `t_transaksi` (`no_transaksi`, `id_pengunjung`, `id_karyawan`, `jml_kamar`, `tgl_masuk`, `tgl_keluar`, `lama_nginap`, `total_harga`) VALUES
(21, '001', '01', 3, '2019-01-18', '2019-01-20', 4, 700000),
(22, '002', '02', 1, '2019-03-05', '2019-02-08', 4, 200000),
(23, '003', '03', 3, '2019-03-15', '2019-03-18', 3, 700000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD PRIMARY KEY (`id_dtl_transaksi`),
  ADD KEY `no_transaksi` (`no_transaksi`),
  ADD KEY `no_kamar` (`no_kamar`);

--
-- Indexes for table `jenis_kamar`
--
ALTER TABLE `jenis_kamar`
  ADD PRIMARY KEY (`id_jenis_kamar`);

--
-- Indexes for table `kamar`
--
ALTER TABLE `kamar`
  ADD PRIMARY KEY (`no_kamar`),
  ADD KEY `id_jenis_kamar` (`id_jenis_kamar`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id_karyawan`);

--
-- Indexes for table `t_pengunjung`
--
ALTER TABLE `t_pengunjung`
  ADD PRIMARY KEY (`id_pengunjung`);

--
-- Indexes for table `t_transaksi`
--
ALTER TABLE `t_transaksi`
  ADD PRIMARY KEY (`no_transaksi`),
  ADD KEY `id_pengunjung` (`id_pengunjung`),
  ADD KEY `id_karyawan` (`id_karyawan`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD CONSTRAINT `detail_transaksi_ibfk_1` FOREIGN KEY (`no_transaksi`) REFERENCES `t_transaksi` (`no_transaksi`),
  ADD CONSTRAINT `detail_transaksi_ibfk_2` FOREIGN KEY (`no_kamar`) REFERENCES `kamar` (`no_kamar`);

--
-- Constraints for table `kamar`
--
ALTER TABLE `kamar`
  ADD CONSTRAINT `kamar_ibfk_1` FOREIGN KEY (`id_jenis_kamar`) REFERENCES `jenis_kamar` (`id_jenis_kamar`);

--
-- Constraints for table `t_transaksi`
--
ALTER TABLE `t_transaksi`
  ADD CONSTRAINT `t_transaksi_ibfk_1` FOREIGN KEY (`id_pengunjung`) REFERENCES `t_pengunjung` (`id_pengunjung`),
  ADD CONSTRAINT `t_transaksi_ibfk_2` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
