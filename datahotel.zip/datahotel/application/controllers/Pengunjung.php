<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Pengunjung extends CI_Controller {
	public function __construct()
	{

	parent::__construct();
	$this->load->model('Pengunjung_model');
  $this->load->library('form_validation');

	}
    public function index()
  {
  	
    $data['judul'] = 'Daftar pengunjung';
  	$data['pengunjung'] = $this->Pengunjung_model->getAllPengunjung();
    if($this->input->post('keyword')){
      $data['pengunjung'] = $this->Pengunjung_model->cariDataPengunjung();
    }
  	$this->load->view('halamanpilih/pengunjung/index',$data);
   }
      
      public function tambah()
      {

            $data['judul'] = 'Form Tambah Data Pengunjung';

            
            $this->form_validation->set_rules('nama_pengunjung','Nama_pengunjung', 'required');
            $this->form_validation->set_rules('alamat','Alamat', 'required');
            $this->form_validation->set_rules('no_telp','No_telp', 'required');
            $this->form_validation->set_rules('no_ktp','No_ktp', 'required');

            if($this->form_validation->run() == FALSE) {

             $this->load->view('halamanpilih/pengunjung/tambah',$data);

            } else {
              $this->Pengunjung_model->tambahDataPengunjung();
              redirect('pengunjung');
            }
            
      }
                public function hapus($id_pengunjung)
                {
                  $this->Pengunjung_model->hapusDataPengunjung($id_pengunjung);
                  redirect('pengunjung');
                }

                public function detail($id_pengunjung)
                {

                  $data['pengunjung'] = $this->Pengunjung_model->getPengunjungById($id_pengunjung);
                  $data['judul'] = 'Detail Data Pengunjung';
                  $this->load->view('halamanpilih/pengunjung/detail',$data);

                }


                public function ubah($id_pengunjung)
      {

            $data['judul'] = 'Form ubah Data Pengunjung';
            $data['pengunjung'] = $this->Pengunjung_model->getPengunjungById($id_pengunjung);
            $data['jenis_kelamin'] = ['pria','wanita'];

            $this->form_validation->set_rules('id_pengunjung','Id_pengunjung', 'required');
            $this->form_validation->set_rules('nama_pengunjung','Nama_pengunjung', 'required');
            $this->form_validation->set_rules('alamat','Alamat', 'required');
            $this->form_validation->set_rules('no_telp','No_telp', 'required');
            $this->form_validation->set_rules('no_ktp','No_ktp', 'required');

            if($this->form_validation->run() == FALSE) {

             $this->load->view('halamanpilih/pengunjung/ubah',$data);

            } else {
              $this->Pengunjung_model->ubahDataPengunjung();
              redirect('pengunjung');
            }
            
      }
    }
              
