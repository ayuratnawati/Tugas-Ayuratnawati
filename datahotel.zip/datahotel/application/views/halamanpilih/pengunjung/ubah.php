<!DOCTYPE html>
<html>
<head>
	<title>Tambah pengunjung</title>
</head>
<body>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css" integrity="sha384-PDle/QlgIONtM1aqA2Qemk5gPOE7wFq8+Em+G/hmo5Iq0CCmYZLv3fVRDJ4MMwEA" crossorigin="anonymous">
<div class ="container">
	<div class="row mt-3">
		<div class="col-md-6">



<div class="card">
  <div class="card-header">
    Form ubah data pengunjung
  </div>

  <div class="card-body">

  	<?php if( validation_errors() ):?>
  	<div class="alert alert-danger" role="alert">
  		<?= validation_errors();?>
  	</div>
  <?php endif;?>
  	<form action="" method="post">
      <input type="hidden" name="id" value="<?= $pengunjung['id_pengunjung'];?>">
        	<div class="form-group">
              <label for="id_pengunjung">id pengunjung</label>
                <input type="number" name="id_pengunjung" class="form-control" id="number" value="<?= $pengunjung['id_pengunjung'];?>">
                  </div>

                  <div class="form-group">
                    <label for="nama_pengunjung">nama pengunjung</label>
                    <input type="text" name="nama_pengunjung" class="form-control" id="text" value="<?= $pengunjung['nama_pengunjung'];?>">
                    </div>

                    <div class="form-group">
                     <label for="alamat">alamat</label>
                     <input type="text" name="alamat" class="form-control" id="text" value="<?= $pengunjung['alamat'];?>">
                     </div>

                     <div class="form-group">
                      <label for="jenis_kelamin">jenis kelamin</label>
                      <select class="form-control" name="jenis_kelamin" id="jenis_kelamin" name="jenis_kelamin">
                      	<?php foreach( $jenis_kelamin as $j) : ?>
                        <?php if( $j == $pengunjung['jenis_kelamin']) :?>
                        <option value="<?= $j;?>" selected><?= $j;?></option>
                        <?php else :?>
                         <option value="<?= $j;?>"><?= $j;?></option>
                         <?php endif;?>
                        <?php endforeach; ?>
                    </select>
                       
                       </div>
                       <div class="form-group">
              <label for="no_telp">no_telp</label>
                <input type="number" name="no_telp" class="form-control" id="number" value="<?= $pengunjung['no_telp'];?>">
                  </div>
                  <div class="form-group">
              <label for="no_ktp">no_ktp</label>
                <input type="number" name="no_ktp" class="form-control" id="number" value="<?= $pengunjung['no_ktp'];?>">
                  </div>
              </select>

              <button type="submit" name="Ubah" class="btn btn-primary">Ubah Data</button>

                   </form>
               </div>
           </div>
       </div>
   </div>
</div>
</body>
    
  