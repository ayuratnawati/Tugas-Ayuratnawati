<!DOCTYPE html>
<html>
<head>
	<title>Tambah pengunjung</title>
</head>
<body>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css" integrity="sha384-PDle/QlgIONtM1aqA2Qemk5gPOE7wFq8+Em+G/hmo5Iq0CCmYZLv3fVRDJ4MMwEA" crossorigin="anonymous">
<div class ="container">
	<div class="row mt-3">
		<div class="col-md-6">



<div class="card">
  <div class="card-header">
    Form Tambah data pengunjung
  </div>

  <div class="card-body">

  	<?php if( validation_errors() ):?>
  	<div class="alert alert-danger" role="alert">
  		<?= validation_errors();?>
  	</div>
  <?php endif;?>
  	<form action="" method="post">
        	
                  <div class="form-group">
                    <label for="nama_pengunjung">nama pengunjung</label>
                    <input type="text" name="nama_pengunjung" class="form-control" id="text">
                    </div>
                    <div class="form-group">
                     <label for="alamat">alamat</label>
                     <input type="text" name="alamat" class="form-control" id="text">
                     </div>
                     <div class="form-group">
                      <label for="jenis_kelamin">jenis kelamin</label>
                      <select class="form-control" name="jenis_kelamin" id="jenis_kelamin" name="jenis_kelamin">
                      	<option></option>
                       <option>pria</option>
                        <option>wanita</option>
                    </select>
                       
                       </div>
                       <div class="form-group">
              <label for="no_telp">no_telp</label>
                <input type="number" name="no_telp" class="form-control" id="number">
                  </div>
                  <div class="form-group">
              <label for="no_ktp">no_ktp</label>
                <input type="number" name="no_ktp" class="form-control" id="number">
                  </div>
              </select>

              <button type="submit" name="tambah" class="btn btn-primary">Tambah Data</button>

                   </form>
               </div>
           </div>
       </div>
   </div>
</div>
</body>
    
  