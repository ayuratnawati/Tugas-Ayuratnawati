 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<div class="container">
	<div class="row mt-3">
		<div class="col-md-6">

			<div class="card">
  <div class="card-header">
    Detail data pengunjung
  </div>
  <div class="card-body">
    <h5 class="card-title">Id_pengunjung   : <?= $pengunjung['id_pengunjung'];?></h5>
    <h5 class="card-title">Nama_pengunjung : <?= $pengunjung['nama_pengunjung'];?></h5>
    <h5 class="card-title">Alamat : <?= $pengunjung['alamat'];?></h5>
    <h5 class="card-title">Jenis_kelamin : <?= $pengunjung['jenis_kelamin'];?></h5>
    <h5 class="card-title">No-Tlp : <?= $pengunjung['no_telp'];?></h5>
    <h5 class="card-title">No-Ktp : <?= $pengunjung['no_ktp'];?></h5>
   
  </div>
</div>
