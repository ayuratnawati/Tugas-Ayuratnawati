<!doctype html> 
<html lang="en">
<head>
  <style>
          .nomor{
            font-size: 30pt;
          }
  </style>

   <link rel="stylesheet" href="<?= base_url(); ?>assets/css/bootstrap.css">
    
    <!-- Native CSS -->
    <link rel ="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/dataeskul.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/kontak/kontak.css">

         <meta charset="utf-8">
         <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

         <title>halaman pilih</title>
         <link rel="stylesheet" type="text/css" href="assets/css/ayurpl.css">
         <link rel="stylesheet" href="assets/css/kontak/kontak.css">

</head>
<body>
        <nav class="navbar navbar-expand-lg navbar-light bg-info">
        <a class="navbar-brand" href="#">Data Hotel</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
</button>
         <div class="collapse navbar-collapse" id="navbarSupportedContent">
         <ul class="navbar-nav mr-auto">
         <li class="nav-item active">
         <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
</li>
          <li class="nav-item">
          <a class="nav-link" href="https://youtu.be/Ow25lvYoKXo">vidio</a>
</li>
          <li class="nav-item">
          <a class="nav-link disabled" href="#"></a>
</li>
</ul>
        
  </div>
</nav>

  <div class="bungkus mt-4">
                    <div class="profile">
                        <div class="photo">
                            <center>
                               <h3 class="mt-3 mb-8"></h3>
                                 <img src="assets/img/5.png" width="200px;">
                            </center>
                        </div>
                           <div class="nomor">
                             <span>Pengunjung</span><br>
                               <span>
                                 <a href="<?= base_url()?>Pengunjung/tambah"><button type="button" class="btn btn-primary"style="width:210px; margin-top: 20px;">Tambah</button>
                            </span></a>
                        </div>
                    </div>

                    <div class="profile">
                        <div class="photo">
                            <center>
                               <h3 class="mt-3 mb-6"></h3>
                                 <img src="assets/img/yuytr.jpg" width="170px;">
                            </center>
                        </div>
                           <div class="nomor">
                             <span>Transaksi</span><br>
                               <span>
                                 <a href ="<?= base_url()?>Transaksi"><button type="button" class="btn btn-primary"style="width:210px; margin-top: 20px;">masuk</button>
                            </span></a>
                        </div>
                    </div>

                  
                    <div class="profile" style="margin-top:50px;">
                        <div class="photo">
                            <center>
                               <h3 class="mt-3 mb-5"></h3>
                                 <img src="assets/img/7.jpg" width="170px;">
                            </center>
                        </div>
                           <div class="nomor">
                             <span>Kamar</span><br>
                               <span>
                                 <button type="button" class="btn btn-primary"style="width:210px; margin-top: 20px;">masuk</button>
                            </span></a>
                        </div>
                    </div>

                    <div class="profile" style="margin-top:50px;">
                        <div class="photo">
                            <center>
                               <h3 class="mt-3 mb-5"></h3>
                                 <img src="assets/img/6.jpg" width="150px;">
                            </center>
                        </div>
                           <div class="nomor">
                             <span>Arsip</span><br>
                               <span>
                                 <a href ="<?= base_url();?>arsip"><button type="button" class="btn btn-primary"style="width:210px; margin-top: 20px;">masuk</button>
                            </span></a>
                        </div>
                    </div>
                  </span></div>

                    <footer style="margin-top:-0px;">
    <div class="konten1">
        <div class="line"></div>
            <h3>Jogja</h3>
            <h3>Champ</h3>
            <P>Aplikasi ini untuk mempermudah admin menginput data pengunjung
            </P>
        </div>
        <div class="konten2">
            <h5>OUR TEAM</h5>
                <div class="line2">
                    <div class="l-line"></div>
                </div>
                <li><a href="#">pengunjung</a></li><hr class="line2">
                <li><a href="#">kamar</a></li><hr class="line2">
                <li><a href="#">Fasilitas</a></li><hr class="line2">
                
        </div>
        <div class="konten3">
            <h5>FOLLOW US</h5>
                <div class="line2">
                    <div class="l-line"></div>
                    <li><a href="#"><i class="fab fa-twitter t" style="margin-left: -60px; padding: 10px; border-radius: 100%;"></i></a></li>
                    <li><a href="#"><i class="fab fa-facebook f" style="margin-left: -5px; padding: 10px 12px; border-radius: 100%;"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram i" style="margin-left: 10px; padding: 10px 12px; border-radius: 100%;"></i></a></li>
                    <li><a href="#"><i class="fab fa-youtube y" style="margin-left: 10px; padding: 10px 10px; border-radius: 100%;"></i></a></li>
                </div>
        </div>
        <div class="konten4">
            <h5>OUR NEWSLETTER</h5>
                <div class="line2">
                    <div class="l-line"></div>
                </div>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum totam pariatur dolor atque minus, laborum impedit eligendi vitae recusandae, distinctio neque itaque, fugit magni incidunt harum aliquid tenetur deleniti! Vero?</p> 
        </div>
    <div class="footer-bottom">
        <p>Copyright &copy; 2019 Ayu ratnawati Production</p>
    </div>
    </footer>
</div>
</body>
</html>






                    

                    
                    