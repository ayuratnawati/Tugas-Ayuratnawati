

<center><div class="box1" style="width: 100%; height: auto; padding: 20px; margin-top:px;">
  <p>Data transaksi</p>
      <h1 style="text-align:center"></h1>
        <div class="table-responsive-vertical">
          <table class="table table-bordered table-striped table-hover table-mc-red">
              <thead>
                <tr>
                <th><b>no_transaksi</b></th>    
                    <th><b>id_pengunjung</b></th>
                    <th><b>id_karyawan</b></th>
                    <th><b>jml_kamar</b></th>
                    <th><b>tgl_masuk</b></th>
                    <th><b>tgl_keluar</b></th>
                    <th><b>lama_nginap</b></th>
                    <th><b>total-hotel</b></th>
                  </tr>
               </thead>
              <tbody>
                 <?php foreach($transaksi as $trn) : ?>
                  <tr>
                        <td data-title="No_transaksi"><?= $trn['no_transaksi']; ?></td>
                        <td data-title="Id_pengunjung"><?= $trn['id_pengunjung']; ?></td>
                        <td data-title="Id_karyawan"><?= $trn['id_karyawan']; ?></td>
                        <td data-title="jml_kamar"><?= $trn['jml_kamar']; ?></td>
                        <td data-title="tgl_masuk"><?= $trn['tgl_masuk']; ?></td>
                        <td data-title="tgl_keluar"><?= $trn['tgl_keluar']; ?></td>
                        <td data-title="lama_nginap"><?= $trn['lama_nginap']; ?></td>
                        <td data-title="total_harga"><?= $trn['total_harga']; ?></td>
                    <?php endforeach; ?>
               </tbody>
           </table>
         </div>




