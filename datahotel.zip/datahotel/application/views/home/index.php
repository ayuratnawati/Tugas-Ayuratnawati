<!doctype html> 
<html lang="en">
<head>
  <style>
          .nomor{
            font-size: 30pt;
          }
  </style>

   <link rel="stylesheet" href="<?= base_url(); ?>assets/css/bootstrap.css">
    
    <!-- Native CSS -->
    <link rel ="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/dataeskul.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/kontak/kontak.css">

         <meta charset="utf-8">
         <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

         <title>halaman pilih</title>
         <link rel="stylesheet" type="text/css" href="assets/css/ayurpl.css">
         <link rel="stylesheet" href="assets/css/kontak/kontak.css">

</head>
<body>
        <nav class="navbar navbar-expand-lg navbar-light bg-info">
        <a class="navbar-brand" href="#">Data Hotel</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
</button>
         <div class="collapse navbar-collapse" id="navbarSupportedContent">
         <ul class="navbar-nav mr-auto">
         <li class="nav-item active">
         <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
</li>
          <li class="nav-item">
          <a class="nav-link" href="https://youtu.be/Ow25lvYoKXo">vidio</a>
</li>
          <li class="nav-item">
          <a class="nav-link disabled" href="#"></a>
</li>
</ul>

<a href="<?= site_url('pilih'); ?>"><button type="button" class="btn btn-success">Register</button></a>
<button type="button" class="btn btn-success" style="margin-left: 20px;">Login</button></a></div>
        
  </div>
</nav>
</head>
<body>
    <style>
        
        body{
            margin: 0px;
            padding: 0px;
            background-color:white;
        }
        .image-top{
            width: 100%;
            height:75vh;
            background-image: url(assets/img/2343.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            margin-top: px;
         }
         .lapisanimage{
              width: 100%;
             height:75vh;
             background-color: rgba(44, 39, 58, 0.35);
             margin-top: -10px;
            }
            .txt-it1{
               color: #fff;
               font-family: informal roman;
               padding-top: 150px;
               padding-left:px;
               font-size: 60px; 
               text-decoration: none; 
            }

              .txt-it2{
                  color: #fff;
                  font-family: informal roman;
                  padding-left:-20px; 
                  font-size:40pt;
                  width: 550px;
                  margin-top: -20px;
             }
         
</style>
     <div class="image-top">
        <div class="lapisanimage">
          <center><h1 class="txt-it1">SELAMAT DATANG ADMIN </h1><br>
            <h3 class="txt-it2">JOGJA CHAMP</h3>
              
              </center>
            </div>
          </div>
        </body>
      </a>
    </div>
  </nav>
</body>
</html>