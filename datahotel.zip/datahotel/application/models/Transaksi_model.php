<?php   

class Transaksi_model extends CI_model {
	public function getAlltransaksi()
	{

		return $this->db->get('t_transaksi')->result_array();
        
	}
}
