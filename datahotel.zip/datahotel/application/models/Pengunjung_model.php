<?php   

class Pengunjung_model extends CI_model {
	public function getAllpengunjung()
	{

		return $this->db->get('t_pengunjung')->result_array();
        
	}

	public function tambahDataPengunjung()
	{
		$data = [

			
			"nama_pengunjung" => $this->input->post('nama_pengunjung',true),
			"alamat"          => $this->input->post('alamat',true),
			"jenis_kelamin"   => $this->input->post('jenis_kelamin',true),
			"no_telp"         => $this->input->post('no_telp',true),
			"no_ktp"          => $this->input->post('no_ktp',true)


		];

           $this->db->insert('t_pengunjung',$data);
	}

	public function hapusDataPengunjung($id_pengunjung)
	{
		$this->db->where('id_pengunjung',$id_pengunjung);
		$this->db->delete('t_pengunjung');
	}

	public function getPengunjungById($id_pengunjung)
	{

		return $this->db->get_where('t_pengunjung', ['id_pengunjung' => $id_pengunjung])->row_array();
	}

	public function cariDatapengunjung()
	{
		$keyword = $this->input->post('keyword',true);
		$this->db->like('nama_pengunjung', $keyword);
		$this->db->or_like('id_pengunjung',$keyword);
		$this->db->or_like('alamat',$keyword);
		return $this->db->get('t_pengunjung')->result_array();
	}


	public function ubahDataPengunjung()
	{
		$data = [

			"id_pengunjung"   => $this->input->post('id_pengunjung',true),
			"nama_pengunjung" => $this->input->post('nama_pengunjung',true),
			"alamat"          => $this->input->post('alamat',true),
			"jenis_kelamin"   => $this->input->post('jenis_kelamin',true),
			"no_telp"         => $this->input->post('no_telp',true),
			"no_ktp"          => $this->input->post('no_ktp',true)


		];

           $this->db->where('id_pengunjung', $this->input->post('id'));
           $this->db->update('t_pengunjung',$data);
	}



}