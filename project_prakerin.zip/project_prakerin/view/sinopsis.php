<!doctype html>
<html lang="en">
<head>
         <meta charset="utf-8">
         <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

         <title>sinopsis</title>
         <link rel="stylesheet" type="text/css" href="../assets/css/sinopsis.css">
</head>
<body>
        <nav class="navbar navbar-expand-lg navbar-light bg-info">
        <a class="navbar-brand" href="#">CINDERELLA</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
</button>
         <div class="collapse navbar-collapse" id="navbarSupportedContent">
         <ul class="navbar-nav mr-auto">
         <li class="nav-item active">
         <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
</li>
          <li class="nav-item">
          <a class="nav-link" href="https://youtu.be/Ow25lvYoKXo">vidio</a>
</li>
          <li class="nav-item">
          <a class="nav-link disabled" href="#"></a>
</li>
</ul>
          <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>
  </div>
</nav>
    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</div>
      <div id ="konten">

      <img src="../assets/img/a.jpg"> 
      <div class="text">
        <center><b>Dahulu kala hiduplah seorang gadis yang hidup dengan Ibu Tiri dan dua saudara tirinya, Cinderella namanya. Cinderella adalah nama yang diberikan oleh Ibu Tiri dan kedua sausara tirinya yang berarti Upik Abu, nama itu diberikan karena dia selalu cemong terkena oleh abu perapian.</p>

          <p>Cinderella selalu mendapat perlakuan buruk dari Ibu tiri dan kedua kakak Tirinya tersebut. Dia selalu diberikan pekerjaan tanpa ada waktu baginya untuk beristirahat. Hidup Cinderella dalam rumahnya sendiri bagaikan seoang pembantu semenjak Ayahnya meninggal Dunia. Namun, meski Cinderella diperlakukan seperti pembantu, Cinderella tidak pernah mengeluh atau pun membantah perkataan kedua kakak dan Ibu Tirinya. Cinderella selalu ceria dan tetap saying pada kedua kakak dan Ibu Tirinya itu. Cinderella yang baik hati, tidak hanya saying keluarganya, dia juga sangat menyayangi binatang-binatang  yang ada disekitarnya.

          <P>ada Suatu hari, penduduk desa dihebohkan oleh sebuah undangan pada tiap rumah. Undangan tersebut merupakan undangan dari kerajaan yang berisi undangan untuk menghadiri pesta dansa yang diselenggarakan oleh kerajaan di Istana untuk mencari calon Istri bagi Pangeran.</P>

Semua rakyat bersiap-siap untuk pergi ke acara pesta dansa tersebut, terutama para gadis yang mengidamkan akan menjadi mendamping untuk pangeran. Begitupun dengan keluarga Cinderella. Kedua kakak dan Ibu Tirinya sudah sejak sore hari bersiap-siap untuk menghadiri acara pesta dansa tersebut. Cinderella sangat sibuk menyiapkan seluruh keperluan bagi Ibu dan Kakak-kakaknya.</p></center>

 <img src="../assets/img/12.jpg"> 

 <br><center><b><p>Setelah siap dengan gaun terbaiknya, Ibu dan Kakak-kakak Tiri Cinderella pun pergi menuju Istana. Dalam hati Cinderella juga sangat ingin pergi ke pesta tersebut, namun walaupun ingin pergi, Cinderella tidak memiliki gaun dan sepatu yang pantas. Dalam kesedihannya karna tidak bisa menghadiri acara pesta tersebut, Cinderella menangis.

<p>Saat menangis sedih, tiba-tiba muncullah sebuah cahaya silau dari hadapannya. Cahaya itu perlahan berubah menjadi seorang Ibu yang sangat cantik memegang sebuah tongkat.
“jangan menangis Cinderella” ucap Ibu tersebut
Cinderella heran dan bertanya “anda siapa?”
“aku Ibu peri” kata Ibu yang memegang tongkat “kenapa kamu bersedih Cinderella?
“aku ingin pergi ke pesta dansa, tapi aku tidak punya gaun yang bagus” ucap Cinderella masih terisak
“jangan hawatir anakku, berdirilah” kata IBu peri sambil menarik Cinderella untuk berdiri “simsalabim…” ucapnya sambil mengayunkan tongkat pada Cinderella. Seketika itu juga baju Cinderella yang tadinya compang camping kini menjadi sebuah gaun yang sangat indah dan cantik.
“wah….indah sekali gaunnya Ibu Peri” ujar Cinderella langsung gembira.
“nah, sekarang kamu bisa pergi ke pesta Dansa itu Cinderella” ucap Ibu Peri.
“tapi, aku tidak memiliki sepatu” kata Cinderella mengangkat roknya sedikit memperlihatkan kaki telanjangnya. Lagi-lagi Ibu Peri mengayunkan tongkatnya dan berkata “simsalabimmm” maka tiba-tiba kaki Cinderella kini memakai sepatu kaca yang sangat cantik.</p>

<p>iklan tengah
class="MsoNormal"> Cinderella sangat bahagia mendapatkan Gaun dan sepatu yang sangat cantik itu, dengan segera dia keluar rumah untuk menuju istana. Sesampai dihalaman, dia baru sadar, jika dia berangkat sekarang dia akan terlambat dan sampai setelah pestanya berahir. Ibu Peri yang menyadari hal itu langsung menyuruh Cinderella untuk mengambilkan sebuah labu kuning yang paling besar.
Cinderella berlari dan mengambil labu tersebut, sekali lagi Peri mengayunkan tongkatnya “simsalabim…” lalu muncullah sebuah kereta kencana yang menawan. Teman-teman binatang Cinderella ikut takjub melihat keajaiban dari tongkat Ibu Peri. Lalu Ibu peri sekali lagi mengayunkan tongkatnya pada BInatang-binatang, 4 ekor tikus langsung berubah menjadi Kuda untuk menarik kereta kencana, seekor kadal berubah menjadi kusir kereta. Maka siaplah kendaraan Cinderella menuju Istana.</p>

<p>Cinderella buru-buru naik ke kereta dan ingin segera berangkat ke Istana sebelum pesta berahir. Tapi Ibu Peri menahannya dan berkata. “Ingat Cinderella, semua keajaiban ini kan hilang saat tepat tengah malan. Jadi pulanglah sebelum tengah malam” kata Ibu Peri memperingatinya. Cinderella mengangguk mengerti dan berangkatlah dia.</p>

<p>Sesampai di Istana, Cinderella langsung menjadi pusat perhatian karena kecantikannya. Pangeran yang sejak tadi belum menemukan pasangan dansa yang cocok langsung terpukau begitu melihat Cinderella. Lalu Pangeran dengan cepat mengajak Cinderella untuk berdansa dengannya. Cinderella sangat bahagia dan menikmati berdansa dengan Pangeran.</p>

<p>Tak dirasa, tiba-tiba jam Istana berdentang menandakan sudah tengah malam. Cinderella kaget mendengarkan bunyi jam tersebut dan langsung berlari meninggalkan Pangeran begitu saja. Dia berlari secepat-cepatnya sebelum semua keajaiban itu berubah kembali menjadi seperti semula.</p>

<p>Ketika berlari menuruni tangga, sepatu kaca sebelah kiri Cinderella terlepas dan Dia tidak sempat mengambilnya karna terlalu buru-buru. Tidak lama sesampainya dirumah, semua kembali berubah seperti semula.</p>

<p>Keesokan harinya, Desa kembali dihebohkan oleh sebuah perintah Pangeran. Rupanya Pangeran mengirim pengawal kerajaan untuk menemukan gadis bersepatu kaca yang menemaninya berdansa semalam. Semua gadis di desa itu diijinkan untuk mengenakan sepatu kaca yang ditinggalkan oleh Cinderella semalam. Barang siapa yang kakinya cocok dengan sepatu tersebut, maka dia akan menjadi Istri Pangeran.</p>

<p>Semua gadis di desa mencoba sepatu kaca tersebut, tapi tidak ada yang kakinya cocok. Hingga tiba giliran rumah Cinderella, kakak-kakak tirinya mencoba mencocokkan kakik mereka kedalam sepatu tersebut, tetapi tidak cocok. Pengawal kerajaan sudah putus asa mencarinya hingga tiba-tiba Cinderella muncul dan bertanya bolehkah dia mencobanya. Ibu dan kedua Kakaknya menertawai Cinderella karna ingin mencoba. “bukankah kamu tidak pergi ke pesta dansa itu? Lalu buat apa kamu mencobanya?” ejek kakak-kakaknya. Namun pengawal kerajaan mengijinkan dia mencobanya karena perintah pangeran adalah untuk semua gadis.</p>

<p>Tanpa diduga, ternyata kaki Cinderella sangat cocok dan pas masuk kedalam sepatu kaca itu, dan lalu tiba-tiba Dia mengeluarkan pasangan sepatu sebelah kanan dari dalam kantung baju lusuhnya. Pengawal kerajaan sangat senang ahirnya menemukan gadis yang dicarinya. Lalu dibawalah Cinderella ke Istana, dia menjadi Istri Pangeran dan hidup bahagia selamanya.</p></center>



      </html>
    </head>